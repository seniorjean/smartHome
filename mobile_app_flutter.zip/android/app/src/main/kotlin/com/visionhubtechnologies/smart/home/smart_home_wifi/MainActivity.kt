package com.visionhubtechnologies.smart.home.smart_home_wifi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
