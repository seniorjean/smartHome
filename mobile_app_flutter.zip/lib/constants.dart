// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

const Color KPrimaryColor = Colors.yellow;
const Color KSecondaryColor = Colors.black;
final Color ScaffoldBgColor = Colors.white;

String globalAddress = '192.168.4.1';
